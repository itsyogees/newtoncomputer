"use client";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";
import { FaShoppingCart, FaPhone, FaEnvelope, FaChevronDown, FaMapMarkerAlt } from "react-icons/fa";
import "./Navbar.scss";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const cartCount = 0;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  // Function to handle laptop store navigation with brand filter
  const handleLaptopStoreClick = (brand = '') => {
    closeMenu();
    // Navigate to laptop store page with brand parameter
    if (brand) {
      // You can use query parameters or dynamic routes
      window.location.href = `/pages/LaptopStore?brand=${brand}`;
    } else {
      window.location.href = '/pages/LaptopStore';
    }
  };

  return (
    <>
      {/* Top Info Bar */}
      <div className={`info-bar ${isScrolled ? 'info-bar--hidden' : ''}`}>
        <div className="info-bar__container">
          <div className="info-bar__contact">
            <FaEnvelope className="info-bar__icon" />
            <a href="mailto:info@newtoncomputers.in">info@newtoncomputers.in</a>
          </div>
          
          <div className="info-bar__status">
            Open Today: 9:30 AM - 8:00 PM
          </div>

          <div className="info-bar__phones">
            <span className="phone-item">
              <FaMapMarkerAlt className="info-bar__icon" />
              <span className="location-badge">T.Nagar</span>
              <FaPhone className="info-bar__icon" />
              <a href="tel:9840604073">9840604073</a>
            </span>
            
            <span className="divider">|</span>
            
            <span className="phone-item">
              <FaMapMarkerAlt className="info-bar__icon" />
              <span className="location-badge">Thoraipakkam</span>
              <FaPhone className="info-bar__icon" />
              <a href="tel:9940185417">9940185417</a>
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <header className={`navbar ${isScrolled ? 'navbar--scrolled' : ''}`}>
        <div className="navbar__container">
          {/* Logo */}
          <div className="navbar__logo">
            <Link href="/">
              <Image 
                src="/logo-newton.png" 
                alt="Newton Computers" 
                width={150} 
                height={50} 
                priority
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="navbar__links">
            <Link href="/" className="nav-item" onClick={closeMenu}>
              Home
            </Link>
            
            {/* Laptop Store Dropdown */}
            <div className="nav-dropdown">
              <span className="nav-item">
                Laptop Store <FaChevronDown className="dropdown-arrow" />
              </span>
              <div className="dropdown-menu">
                <Link 
                  href="/pages/LaptopStore" 
                  className="nav-item"
                  onClick={() => handleLaptopStoreClick('')}
                >
                  All Laptops
                </Link>
                <Link 
                  href="/pages/LaptopStore?brand=dell" 
                  className="nav-item"
                  onClick={() => handleLaptopStoreClick('dell')}
                >
                  Dell Laptops
                </Link>
                <Link 
                  href="/pages/LaptopStore?brand=lenovo" 
                  className="nav-item"
                  onClick={() => handleLaptopStoreClick('lenovo')}
                >
                  Lenovo Laptops
                </Link>
                <Link 
                  href="/pages/LaptopStore?brand=hp" 
                  className="nav-item"
                  onClick={() => handleLaptopStoreClick('hp')}
                >
                  HP Laptops
                </Link>
                <Link 
                  href="/pages/LaptopStore?brand=acer" 
                  className="nav-item"
                  onClick={() => handleLaptopStoreClick('acer')}
                >
                  Acer Laptops
                </Link>
                <Link 
                  href="/pages/LaptopStore?brand=asus" 
                  className="nav-item"
                  onClick={() => handleLaptopStoreClick('asus')}
                >
                  ASUS Laptops
                </Link>
                <Link 
                  href="/pages/LaptopStore?brand=msi" 
                  className="nav-item"
                  onClick={() => handleLaptopStoreClick('msi')}
                >
                  MSI Laptops
                </Link>
              </div>
            </div>

            {/* Laptop Services Dropdown */}
            <div className="nav-dropdown">
              <span className="nav-item">
                Laptop Services <FaChevronDown className="dropdown-arrow" />
              </span>
              <div className="dropdown-menu">
                <Link href="/services/repair" onClick={closeMenu}>Laptop Damage</Link>
                <Link href="/services/upgrade" onClick={closeMenu}>Chip Level Service</Link>
                <Link href="/services/maintenance" onClick={closeMenu}>Laptop Upgrade</Link>
                <Link href="/services/data-recovery" onClick={closeMenu}>Data Recovery</Link>
                <Link href="/services/accessories" onClick={closeMenu}>Laptop Accessories</Link>
              </div>
            </div>

            {/* IT Services Dropdown */}
            <div className="nav-dropdown">
              <span className="nav-item">
                IT Services <FaChevronDown className="dropdown-arrow" />
              </span>
              <div className="dropdown-menu">
                <Link href="/it-services/business-email" onClick={closeMenu}>Business Mail Services</Link>
                <Link href="/it-services/network-security" onClick={closeMenu}>Network Security Solutions</Link>
                <Link href="/it-services/server-storage" onClick={closeMenu}>Server and Storage Solutions</Link>
                <Link href="/it-services/wifi-networking" onClick={closeMenu}>Wi-Fi and Networking Solutions</Link>
                <Link href="/it-services/cctv" onClick={closeMenu}>CCTV Solution</Link>
                <Link href="/it-services/cloud-hosting" onClick={closeMenu}>Cloud hosting services</Link>
              </div>
            </div>

            {/* Contact Dropdown */}
            <div className="nav-dropdown">
              <span className="nav-item">
                Contact Us <FaChevronDown className="dropdown-arrow" />
              </span>
              <div className="dropdown-menu">
                <Link href="/about" onClick={closeMenu}>About Us</Link>
                <Link href="/branches" onClick={closeMenu}>Branches</Link>
                <Link href="/contact" onClick={closeMenu}>Contact Form</Link>
              </div>
            </div>
          </nav>

          {/* Desktop Actions */}
          <div className="navbar__actions">
            <Link href="/cart" className="cart">
              <FaShoppingCart className="cart-icon" />
              <span className="cart-text">Cart</span>
              {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
            </Link>
            <Link href="/book-service" className="book-btn">
              BOOK SERVICE
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="navbar__toggle"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            <span className={`hamburger ${isMenuOpen ? 'hamburger--active' : ''}`}>
              <span></span>
              <span></span>
              <span></span>
            </span>
          </button>
        </div>

        {/* Mobile Navigation */}
        <div className={`navbar__mobile ${isMenuOpen ? 'navbar__mobile--active' : ''}`}>
          <nav className="navbar__mobile-links">
            <Link href="/" className="nav-item" onClick={closeMenu}>
              Home
            </Link>
            
            {/* Mobile Laptop Store Dropdown */}
            <div className="mobile-dropdown">
              <details>
                <summary>Laptop Store</summary>
                <div className="mobile-dropdown-content">
                  <Link 
                    href="/pages/LaptopStore" 
                    onClick={() => handleLaptopStoreClick('')}
                  >
                    All Laptops
                  </Link>
                  <Link 
                    href="/pages/LaptopStore?brand=dell" 
                    onClick={() => handleLaptopStoreClick('dell')}
                  >
                    Dell Laptops
                  </Link>
                  <Link 
                    href="/pages/LaptopStore?brand=lenovo" 
                    onClick={() => handleLaptopStoreClick('lenovo')}
                  >
                    Lenovo Laptops
                  </Link>
                  <Link 
                    href="/pages/LaptopStore?brand=hp" 
                    onClick={() => handleLaptopStoreClick('hp')}
                  >
                    HP Laptops
                  </Link>
                  <Link 
                    href="/pages/LaptopStore?brand=acer" 
                    onClick={() => handleLaptopStoreClick('acer')}
                  >
                    Acer Laptops
                  </Link>
                  <Link 
                    href="/pages/LaptopStore?brand=asus" 
                    onClick={() => handleLaptopStoreClick('asus')}
                  >
                    ASUS Laptops
                  </Link>
                  <Link 
                    href="/pages/LaptopStore?brand=msi" 
                    onClick={() => handleLaptopStoreClick('msi')}
                  >
                    MSI Laptops
                  </Link>
                </div>
              </details>
            </div>

            {/* Mobile Laptop Services Dropdown */}
            <div className="mobile-dropdown">
              <details>
                <summary>Laptop Services</summary>
                <div className="mobile-dropdown-content">
                  <Link href="/services/repair" onClick={closeMenu}>Laptop Damage</Link>
                  <Link href="/services/upgrade" onClick={closeMenu}>Chip Level Service</Link>
                  <Link href="/services/maintenance" onClick={closeMenu}>Laptop Upgrade</Link>
                  <Link href="/services/data-recovery" onClick={closeMenu}>Data Recovery</Link>
                  <Link href="/services/accessories" onClick={closeMenu}>Laptop Accessories</Link>
                </div>
              </details>
            </div>

            {/* Mobile IT Services Dropdown */}
            <div className="mobile-dropdown">
              <details>
                <summary>IT Services</summary>
                <div className="mobile-dropdown-content">
                  <Link href="/it-services/business-email" onClick={closeMenu}>Business Mail Services</Link>
                  <Link href="/it-services/network-security" onClick={closeMenu}>Network Security Solutions</Link>
                  <Link href="/it-services/server-storage" onClick={closeMenu}>Server and Storage Solutions</Link>
                  <Link href="/it-services/wifi-networking" onClick={closeMenu}>Wi-Fi and Networking Solutions</Link>
                  <Link href="/it-services/cctv" onClick={closeMenu}>CCTV Solution</Link>
                  <Link href="/it-services/cloud-hosting" onClick={closeMenu}>Cloud hosting services</Link>
                </div>
              </details>
            </div>

            {/* Mobile Contact Dropdown */}
            <div className="mobile-dropdown">
              <details>
                <summary>Contact Us</summary>
                <div className="mobile-dropdown-content">
                  <Link href="/about" onClick={closeMenu}>About Us</Link>
                  <Link href="/branches" onClick={closeMenu}>Branches</Link>
                  <Link href="/contact" onClick={closeMenu}>Contact Form</Link>
                </div>
              </details>
            </div>
            
            {/* Mobile Actions */}
            <div className="navbar__mobile-actions">
              <Link href="/cart" className="cart-mobile" onClick={closeMenu}>
                <FaShoppingCart className="cart-icon" />
                <span>Cart {cartCount > 0 && `(${cartCount})`}</span>
              </Link>
              <Link href="/book-service" className="book-btn-mobile" onClick={closeMenu}>
                BOOK SERVICE
              </Link>
            </div>
          </nav>
        </div>

        {isMenuOpen && (
          <div 
            className="navbar__overlay"
            onClick={closeMenu}
          ></div>
        )}
      </header>
    </>
  );
}