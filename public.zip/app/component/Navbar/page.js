"use client";
import Link from "next/link";
import Image from "next/image";
import { useState, useEffect } from "react";
import { FaShoppingCart, FaPhone, FaEnvelope, FaChevronDown, FaMapMarkerAlt } from "react-icons/fa";
import "./Navbar.scss";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const cartCount = 0;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <>
      {/* Top Info Bar */}
      <div className={`info-bar ${isScrolled ? 'info-bar--hidden' : ''}`}>
        <div className="info-bar__container">
          <div className="info-bar__contact">
            <FaEnvelope className="info-bar__icon" />
            <a href="mailto:info@newtoncomputers.in">info@newtoncomputers.in</a>
          </div>
          
          <div className="info-bar__status">
            Open Today: 9:30 AM - 8:00 PM
          </div>

          <div className="info-bar__phones">
            <span className="phone-item">
              <FaMapMarkerAlt className="info-bar__icon" />
              <span className="location-badge">T.Nagar</span>
              <FaPhone className="info-bar__icon" />
              <a href="tel:9840604073">9840604073</a>
            </span>
            
            <span className="divider">|</span>
            
            <span className="phone-item">
              <FaMapMarkerAlt className="info-bar__icon" />
              <span className="location-badge">Thoraipakkam</span>
              <FaPhone className="info-bar__icon" />
              <a href="tel:9940185417">9940185417</a>
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <header className={`navbar ${isScrolled ? 'navbar--scrolled' : ''}`}>
        <div className="navbar__container">
          {/* Logo */}
          <div className="navbar__logo">
            <Image 
              src="/logo-newton.png" 
              alt="Newton Computers" 
              width={150} 
              height={50} 
              priority
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="navbar__links">
            <Link href="/" className="nav-item" onClick={closeMenu}>
              Home
            </Link>
            <div className="nav-dropdown">
              <span className="nav-item">
                Laptop Store <FaChevronDown className="dropdown-arrow" />
              </span>
              <div className="dropdown-menu">
                <Link href="/laptops/lenovo" onClick={closeMenu}>Lenovo</Link>
                <Link href="/laptops/dell" onClick={closeMenu}>Dell</Link>
                <Link href="/laptops/hp" onClick={closeMenu}>HP</Link>
                <Link href="/laptops/acer" onClick={closeMenu}>Acer</Link>
                <Link href="/laptops/asus" onClick={closeMenu}>Asus</Link>
              </div>
            </div>
            <div className="nav-dropdown">
              <span className="nav-item">
                Laptop Services <FaChevronDown className="dropdown-arrow" />
              </span>
              <div className="dropdown-menu">
                <Link href="/services/repair" onClick={closeMenu}>Laptop Repair</Link>
                <Link href="/services/upgrade" onClick={closeMenu}>Upgrade Services</Link>
                <Link href="/services/maintenance" onClick={closeMenu}>Maintenance</Link>
              </div>
            </div>
            <div className="nav-dropdown">
              <span className="nav-item">
                IT Services <FaChevronDown className="dropdown-arrow" />
              </span>
              <div className="dropdown-menu">
                <Link href="/it-services/network" onClick={closeMenu}>Network Solutions</Link>
                <Link href="/it-services/software" onClick={closeMenu}>Software Installation</Link>
                <Link href="/it-services/support" onClick={closeMenu}>IT Support</Link>
              </div>
            </div>
            <Link href="/contact" className="nav-item" onClick={closeMenu}>
              Contact Us
            </Link>
          </nav>

          {/* Desktop Actions */}
          <div className="navbar__actions">
            <Link href="/cart" className="cart">
              <FaShoppingCart className="cart-icon" />
              <span className="cart-text">Cart</span>
              {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
            </Link>
            <Link href="/book-service" className="book-btn">
              BOOK SERVICE
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="navbar__toggle"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            <span className={`hamburger ${isMenuOpen ? 'hamburger--active' : ''}`}>
              <span></span>
              <span></span>
              <span></span>
            </span>
          </button>
        </div>

        {/* Mobile Navigation */}
        <div className={`navbar__mobile ${isMenuOpen ? 'navbar__mobile--active' : ''}`}>
          <nav className="navbar__mobile-links">
            <Link href="/" className="nav-item" onClick={closeMenu}>
              Home
            </Link>
            <div className="mobile-dropdown">
              <details>
                <summary>Laptop Store</summary>
                <div className="mobile-dropdown-content">
                  <Link href="/laptops/lenovo" onClick={closeMenu}>Lenovo</Link>
                  <Link href="/laptops/dell" onClick={closeMenu}>Dell</Link>
                  <Link href="/laptops/hp" onClick={closeMenu}>HP</Link>
                  <Link href="/laptops/acer" onClick={closeMenu}>Acer</Link>
                  <Link href="/laptops/asus" onClick={closeMenu}>Asus</Link>
                </div>
              </details>
            </div>
            <div className="mobile-dropdown">
              <details>
                <summary>Laptop Services</summary>
                <div className="mobile-dropdown-content">
                  <Link href="/services/repair" onClick={closeMenu}>Laptop Repair</Link>
                  <Link href="/services/upgrade" onClick={closeMenu}>Upgrade Services</Link>
                  <Link href="/services/maintenance" onClick={closeMenu}>Maintenance</Link>
                </div>
              </details>
            </div>
            <div className="mobile-dropdown">
              <details>
                <summary>IT Services</summary>
                <div className="mobile-dropdown-content">
                  <Link href="/it-services/network" onClick={closeMenu}>Network Solutions</Link>
                  <Link href="/it-services/software" onClick={closeMenu}>Software Installation</Link>
                  <Link href="/it-services/support" onClick={closeMenu}>IT Support</Link>
                </div>
              </details>
            </div>
            <Link href="/contact" className="nav-item" onClick={closeMenu}>
              Contact Us
            </Link>
            
            {/* Mobile Actions */}
            <div className="navbar__mobile-actions">
              <Link href="/cart" className="cart-mobile" onClick={closeMenu}>
                <FaShoppingCart className="cart-icon" />
                <span>Cart {cartCount > 0 && `(${cartCount})`}</span>
              </Link>
              <Link href="/book-service" className="book-btn-mobile" onClick={closeMenu}>
                BOOK SERVICE
              </Link>
            </div>
          </nav>
        </div>

        {isMenuOpen && (
          <div 
            className="navbar__overlay"
            onClick={closeMenu}
          ></div>
        )}
      </header>
    </>
  );
}